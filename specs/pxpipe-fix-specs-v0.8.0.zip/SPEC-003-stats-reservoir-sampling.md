# SPEC-003: Резервуарная выборка в `Summary`

| Поле | Значение |
|---|---|
| **Приоритет** | 🔴 Высокий |
| **Категория** | Производительность / память |
| **Файлы** | `src/stats.ts` |
| **Связь с аудитом** | пункт 2.4 |
| **Объём работ** | 3-4 часа |
| **Breaking change** | Да: `durationMs`/`firstByteMs` (массивы) удалены; ключи в `summaryToJson()` те же |

## Проблема

В `Summary` (`src/stats.ts:18-26`) поля `durationMs: number[]` и `firstByteMs: number[]` хранят **все** значения за время сессии:

```ts
export interface Summary {
  // ...
  durationMs: number[];
  firstByteMs: number[];
  // ...
}
```

`fold()` (`src/stats.ts:64-65`) пушит в массив каждое событие. При 500K событий это ~8 MB памяти только под эти массивы.

Поверх этого `renderTextReport` (`src/stats.ts:180-181`) **дополнительно** копирует и сортирует массив на каждом вызове:

```ts
const sortedDur = [...s.durationMs].sort((a, b) => a - b);
const sortedFB = [...s.firstByteMs].sort((a, b) => a - b);
```

`O(n log n)` на **каждом** percentile-call. Для 500K событий — 10M сравнений. `/api/stats.json` для большого `events.jsonl` может занять секунды.

## Требования

1. Заменить `number[]` на фиксированный **reservoir** с алгоритмом Vitter R.
2. Capacity по умолчанию: 1024. Экспортируется как константа для тестов и документации.
3. Алгоритм: Algorithm R (простой, без quickselect).
4. Percentile — единственный метод расчёта; внутренняя сортировка делается один раз при запросе.
5. Backward-compat по выходным ключам: `durationP50/P95`, `firstByteP50/P95` остаются в `summaryToJson()`.

## Дизайн

### `src/stats.ts`

```ts
/** Размер резервуара для percentile-расчётов. 1024 — математически достаточно для ±3% точности p95/p99. */
export const SUMMARY_RESERVOIR_CAPACITY = 1024;

/**
 * Резервуар Vitter Algorithm R: добавляет элементы в первые `capacity`
 * позиций, потом с вероятностью `capacity / seen` замещает случайный.
 * Гарантирует равномерное распределение sample size.
 */
export class Reservoir {
  private samples: number[] = [];
  private seen = 0;

  constructor(public readonly capacity: number = SUMMARY_RESERVOIR_CAPACITY) {
    if (capacity < 1) throw new Error('capacity must be >= 1');
  }

  add(v: number): void {
    this.seen++;
    if (this.samples.length < this.capacity) {
      this.samples.push(v);
      return;
    }
    // Algorithm R: pick random index in [0, seen).
    const idx = Math.floor(Math.random() * this.seen);
    if (idx < this.capacity) this.samples[idx] = v;
  }

  /** Percentile (P-th, lower-bound). Сортирует внутренний массив на каждом вызове;
   *  O(capacity log capacity) — для capacity=1024 это ≤ 10K операций. */
  percentile(p: number): number {
    if (this.samples.length === 0) return 0;
    if (p < 0 || p > 100) throw new Error('p must be in [0, 100]');
    const sorted = [...this.samples].sort((a, b) => a - b);
    const idx = Math.min(sorted.length - 1, Math.floor((p / 100) * sorted.length));
    return sorted[idx]!;
  }

  /** Количество элементов в текущем sample. */
  size(): number { return this.samples.length; }

  /** Сколько элементов наблюдалось (включая вытесненные). */
  seenCount(): number { return this.seen; }
}

export interface Summary {
  total: number;
  ok2xx: number;
  err4xx: number;
  err5xx: number;
  compressed: number;
  passthrough: number;
  origCharsTotal: number;
  imageBytesTotal: number;
  inputTokensTotal: number;
  outputTokensTotal: number;
  cacheCreateTokensTotal: number;
  cacheReadTokensTotal: number;
  cacheHitEvents: number;
  eventsWithUsage: number;
  durationSample: Reservoir;     // БЫЛО: durationMs: number[]
  firstByteSample: Reservoir;    // БЫЛО: firstByteMs: number[]
  skipReasons: Map<string, number>;
  byCwd: Map<string, { count: number; origChars: number; imageBytes: number }>;
  systemShaHist: Map<string, number>;
  unknownTags: Map<string, number>;
}

export function newSummary(): Summary {
  return {
    // ... существующие поля ...
    durationSample: new Reservoir(),
    firstByteSample: new Reservoir(),
    // УДАЛЕНО: durationMs, firstByteMs
  };
}

export function fold(s: Summary, ev: TrackEvent): Summary {
  // ...
  if (typeof ev.duration_ms === 'number') s.durationSample.add(ev.duration_ms);
  if (typeof ev.first_byte_ms === 'number') s.firstByteSample.add(ev.first_byte_ms);
  // ...
}

// В renderTextReport и summaryToJson:
//   БЫЛО:  const sortedDur = [...s.durationMs].sort(...)
//   СТАЛО: const p50 = s.durationSample.percentile(50)
//         const p95 = s.durationSample.percentile(95)
//         const p99 = s.durationSample.percentile(99)
```

### Обновление `summaryToJson`

```ts
export function summaryToJson(s: Summary): Record<string, unknown> {
  const topN = <K, V>(m: Map<K, V>, n = 20): [K, V][] => [...m.entries()].slice(0, n);
  return {
    // ... существующие поля ...
    durationP50: s.durationSample.percentile(50),
    durationP95: s.durationSample.percentile(95),
    firstByteP50: s.firstByteSample.percentile(50),
    firstByteP95: s.firstByteSample.percentile(95),
    // НЕ выставляем durationSample/firstByteSample в JSON — это служебная структура.
    skipReasons: topN(s.skipReasons),
    byCwd: topN(s.byCwd),
    systemShaHist: topN(s.systemShaHist),
    unknownTags: topN(s.unknownTags),
  };
}
```

> ⚠️ **Breaking change в дашборде:** если дашборд (`src/dashboard.ts`) обращается к `summary.durationMs` напрямую — обновить. По аудиту dashboard читает через `/api/stats.json` → `summaryToJson()` → ключи остаются те же. Но если есть прямые обращения — обновить.

## Acceptance Criteria

- [ ] Память под `durationSample + firstByteSample` ≤ 8 KB независимо от числа событий.
- [ ] Percentile p95 на 100K событий с известным распределением — результат в пределах ±3% от точного.
- [ ] `summaryToJson()` содержит ключи `durationP50`, `durationP95`, `firstByteP50`, `firstByteP95`. Поля `durationMs`/`firstByteMs` (массивы) **удалены**.
- [ ] `renderTextReport()` продолжает работать, формат не изменился визуально.
- [ ] Snapshot-тест в `tests/stats.test.ts` фиксирует точный текстовый вывод (можно сравнить с эталоном из `tests/fixtures/stats-expected.txt`).
- [ ] Все существующие тесты в `tests/stats.test.ts` проходят (обновить вызовы `newSummary`/`fold`/etc).

## Тесты

### tests/reservoir.test.ts (новый)

```ts
import { describe, expect, it } from 'vitest';
import { Reservoir, SUMMARY_RESERVOIR_CAPACITY } from '../src/stats.js';

describe('Reservoir (Vitter R)', () => {
  it('adds first capacity items verbatim', () => {
    const r = new Reservoir(8);
    for (let i = 1; i <= 8; i++) r.add(i);
    expect(r.size()).toBe(8);
    expect(r.seenCount()).toBe(8);
    expect(r.percentile(50)).toBeGreaterThan(0); // not zero
  });

  it('percentile approximates known distribution', () => {
    const r = new Reservoir(64);
    for (let i = 1; i <= 100_000; i++) r.add(i);
    const p50 = r.percentile(50);
    const p95 = r.percentile(95);
    expect(p50).toBeGreaterThan(45_000);
    expect(p50).toBeLessThan(55_000);
    expect(p95).toBeGreaterThan(90_000);
    expect(p95).toBeLessThan(99_000);
  });

  it('caps memory at capacity', () => {
    const r = new Reservoir(128);
    for (let i = 0; i < 10_000_000; i++) r.add(i);
    expect(r.size()).toBe(128);
    expect(r.seenCount()).toBe(10_000_000);
  });

  it('percentile of empty reservoir is 0', () => {
    const r = new Reservoir(8);
    expect(r.percentile(50)).toBe(0);
    expect(r.percentile(95)).toBe(0);
  });

  it('rejects invalid capacity/p', () => {
    expect(() => new Reservoir(0)).toThrow();
    const r = new Reservoir(8);
    expect(() => r.percentile(-1)).toThrow();
    expect(() => r.percentile(101)).toThrow();
  });

  it('percentile is O(capacity log capacity)', () => {
    const r = new Reservoir(SUMMARY_RESERVOIR_CAPACITY);
    for (let i = 0; i < 1_000; i++) r.add(Math.random() * 1000);
    const t0 = performance.now();
    for (let p = 0; p <= 100; p++) r.percentile(p);
    expect(performance.now() - t0).toBeLessThan(50);
  });
});
```

### tests/stats.test.ts (расширение)

```ts
it('Summary over 1M events uses bounded memory for percentile', () => {
  const s = newSummary();
  for (let i = 0; i < 1_000_000; i++) {
    fold(s, { ts: '', method: 'POST', path: '/x', status: 200, duration_ms: Math.random() * 1000, first_byte_ms: Math.random() * 100 });
  }
  // Размер Reservoir = capacity всегда.
  expect(s.durationSample.size()).toBe(SUMMARY_RESERVOIR_CAPACITY);
  expect(s.firstByteSample.size()).toBe(SUMMARY_RESERVOIR_CAPACITY);
  // p95 в пределах разумного.
  expect(s.durationSample.percentile(95)).toBeGreaterThan(900);
  expect(s.durationSample.percentile(95)).toBeLessThan(1000);
});

it('summaryToJson contains all percentile keys', () => {
  const s = newSummary();
  fold(s, { ts: '', method: 'POST', path: '/x', status: 200, duration_ms: 100, first_byte_ms: 50 });
  const json = summaryToJson(s) as Record<string, number>;
  expect(json.durationP50).toBeGreaterThan(0);
  expect(json.durationP95).toBeGreaterThan(0);
  expect(json.firstByteP50).toBeGreaterThan(0);
  expect(json.firstByteP95).toBeGreaterThan(0);
});
```

## Обратная совместимость

### Сломано (нужно обновить):

- `Summary.durationMs` (number[]) → `Summary.durationSample` (Reservoir).
- `Summary.firstByteMs` (number[]) → `Summary.firstByteSample` (Reservoir).
- Любой код, читающий `s.durationMs.length` или `[...s.durationMs]` напрямую.

### Обратная совместимость сохранена:

- `summaryToJson()` ключи: `durationP50`, `durationP95`, `firstByteP50`, `firstByteP95` — без изменений.
- `renderTextReport()` формат — без изменений (только внутренний источник чисел меняется).
- `/api/stats.json` контракт — без изменений для существующих клиентов.

## Открытые вопросы

- **Q1:** Должны ли `durationSample` и `firstByteSample` быть в публичном API `Summary`, или private-полями с методами `percentile(key, p)`? Последнее чище.
  - **Решение:** публичные, чтобы дашборд мог смотреть `size()` и `seenCount()` для UI-индикаторов («sample quality»).
- **Q2:** Нужно ли поддерживать p99/p99.9 в API? Сейчас код считает p50/p95/p99 в `renderTextReport`. Сохранить.
- **Q3:** Math.random vs crypto-secure RNG для тестов — для выборки статистики Math.random достаточно, не нужна криптостойкость.

## Чеклист PR

- [ ] `src/stats.ts`: `Reservoir` класс, заменены поля в `Summary`, обновлены `fold`/`renderTextReport`/`summaryToJson`.
- [ ] `tests/reservoir.test.ts`: 6 unit-тестов, все проходят.
- [ ] `tests/stats.test.ts`: расширены существующие тесты.
- [ ] `src/dashboard.ts`: если есть прямые обращения к `summary.durationMs`, обновить.
- [ ] `tests/fixtures/stats-expected.txt`: эталон для snapshot.
- [ ] `pnpm typecheck && pnpm test` — чисто.
- [ ] Performance sanity check: профиль памяти при `aggregateEventsFile` на 100 MB JSONL ≤ 50 MB (было: 120+ MB).
